
#ifndef __TEST_MULTI_RES_SCENE_H_
#define __TEST_MULTI_RES_SCENE_H_

#include "cocos2d.h"

USING_NS_CC;

class TestMultiResScene : public CCScene
{
public:
    static TestMultiResScene* create(void);

private:
    TestMultiResScene(void)
    {
    }
    bool init(void);
};

#endif
