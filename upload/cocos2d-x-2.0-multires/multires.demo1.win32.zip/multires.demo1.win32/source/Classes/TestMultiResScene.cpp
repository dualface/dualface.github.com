
#include "TestMultiResScene.h"
#include "SmartRes.h"

TestMultiResScene* TestMultiResScene::create(void)
{
    TestMultiResScene* scene = new TestMultiResScene();
    scene->init();
    scene->autorelease();
    return scene;
}

bool TestMultiResScene::init(void)
{
    CCScene::init();

    CCSprite* bg = CCSprite::create("bg.jpg");
    bg->setPosition(_center);
    addChild(bg);

    CCSprite* title = CCSprite::create("title.png");
    title->setPosition(ccp(_center.x, _center.y + 120));
    addChild(title);

    CCSprite* buttonPlay = CCSprite::create("buttonPlay.png");
    buttonPlay->setPosition(ccp(_center.x - 220, _bottom + 140));
    addChild(buttonPlay);

    CCSprite* buttonMore = CCSprite::create("buttonMore.png");
    buttonMore->setPosition(ccp(_center.x + 220, _bottom + 140));
    addChild(buttonMore);

    return true;
}
